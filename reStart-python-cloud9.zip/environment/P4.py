#Lists, Tuples, and Dictionaries
print("Lists, Tuples, and Dictionaries")

#Lists
print("LISTS")

myCarList = ["BMW", "Audi", "RR"]
print(myCarList)
print(type(myCarList))

#Accessing a list by position
print(myCarList[1])
print(myCarList[0])

#Changing the values in a list
myCarList[2] = "Mercedes"
print(myCarList)

#Tuples
print("TUPLES")
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

#Accessing a list by position
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[0])

#Dictionary
print("DICTIONARY")
myFavoriteinstrumenttDictionary = {
  "Rahul" : "Guitar",
  "Akshay" : "Keyboard",
  "Yosheta" : "Drums"
}
print(myFavoriteinstrumenttDictionary)
print(type(myFavoriteinstrumenttDictionary))

#Accessing a dictionary by name
print(myFavoriteinstrumenttDictionary["Yosheta"])
print(myFavoriteinstrumenttDictionary["Rahul"])


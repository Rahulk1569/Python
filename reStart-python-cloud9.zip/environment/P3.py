#String Data Type
myString="Hello, Rahul here."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))

#String Concatenation
string1="Rahul"
string2="Kharat"
string3= string1+string2
print(string3)

#Input String
name= input ("What is your name ? ")
print(name)

#Formatting output strings
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))

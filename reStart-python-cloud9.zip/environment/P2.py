#Python has three numeric types: int, float, and complex
print("Python has three numeric types: int, float, and complex")

#Int
a = 1
print(a)
print(type(a))
print(str(a) + " is of the data type " + str(type(a)))

#Float
b = 1.5
print(b)
print(type(b))
print(str(b) + " is of the data type " + str(type(b)))

#Complex
c = 5j
print(c)
print(type(c))
print(str(c) + " is of the data type " + str(type(c)))

#Boolean
d = True
print(d)
print(type(d))
print(str(d) + " is of the data type " + str(type(d)))

e = False
print(e)
print(type(e))
print(str(e) + " is of the data type " + str(type(e)))
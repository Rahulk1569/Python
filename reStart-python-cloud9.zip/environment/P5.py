#Categorizing Values
myMixedTypeList = [50, 261103, 8.26, True, "I am a Musician", "2611"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
